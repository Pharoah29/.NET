﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private DateTime _startTime = DateTime.Now;
       

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "Text File (*.txt)|*.txt|Adobe Acrobat File (*.pdf)|*.pdf|All Files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            DateTime start = DateTime.Now;

            DialogResult result = openFileDialog1.ShowDialog();

    

            if (result == DialogResult.OK) // Test result.
            {
                //Do whatever you want
                //openFileDialog1.FileName .....

                if ((myStream = openFileDialog1.OpenFile()) != null)
                {

                    FileInfo fileInfo = new FileInfo(openFileDialog1.FileName);

                    toolStripLabel4.Text = fileInfo.Name;

                    this.toolStrip1.Visible = true;


                    using (myStream)
                    {
                        long size = fileInfo.Length / 1024;

                        toolStripLabel6.Text =  (size + ((size) > 0 ? " kb" : fileInfo.Length+" bytes"));

                        TimeSpan ts = DateTime.Now.Subtract(start);
                          
                       // MessageBox.Show(ts.Minutes + "m "+ ts.Seconds + "s "+ ts.Milliseconds + "ms");
                    }
                }

            }
        }

  

        private void Form1_Load(object sender, EventArgs e)
        {
            this.toolStrip1.Visible = false;

            this.toolStripLabel2.Text = "00:00";

           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan ts = DateTime.Now.Subtract(_startTime);

            this.toolStripLabel2.Text = ts.Minutes.ToString("00.##") + ":" + ts.Seconds.ToString("00.##");


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _startTime = DateTime.Now;

            this.timer1.Start();

            button1.Enabled = false;    
            button2.Enabled = false;

           
        }

        private void helpToolStripButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("", "מידע", MessageBoxButtons.OK);
        }
    }
}
